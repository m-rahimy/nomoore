nO mooRe - Changelog
=========

### Version 1.5 - September 1, 2018

* Fixed audio bugs
* Fixed synchronization bugs
* Optimized for latest Android versions
* Optimized for tablets
* Added in-game download links

### Version 1.4 - February 27, 2018

* App icon updated
* Updated to libGDX v1.9.8 with lots of fixes and improvements
* Optimized for latest Android versions

### Version 1.3 - March 5, 2017

* Improved synchronization between Animation and Music
* Decreased swipe speed after last cutscene
* Fixed bug with last message not showing when painting the stone
* Fixed text errors

### Version 1.2 - February 3, 2017

* Improved time traveling
* Fixed inventory flickering
* Made handles more subtle

### Version 1.1 - January 26, 2017

* Made handles swipeable
* Added subtle hints to find interactable items more easily
* Fixed text errors
* Fixed bugs with non-ending cutscenes

### Version 1.0.1 - December 17, 2016

* Larger handles for navigation
* Larger selection areas of items in the inventory
* Better synchronization between Animation and Music
* Better memory management
* Added keyboard support (A, D, Cursor Left, Cursor Right) for navigation
* Fixed a bug in the inventory when receiving the bloody goblet
* Fixed the unexpected playback stop of the creepy drums music
* Fixed wrong music playback if screen is touched in Medieval cutscene

### Version 1.0.0 - December 12, 2016

* First release
